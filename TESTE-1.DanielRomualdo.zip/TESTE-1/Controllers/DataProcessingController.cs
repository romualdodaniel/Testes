using Microsoft.AspNetCore.Mvc;

namespace AsyncDataProcessing.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataProcessingController : ControllerBase
    {
        [HttpPost("process")]
        public async Task<IActionResult> ProcessDataAsync([FromBody] List<int> numbers)
        {
            try
            {
                List<Task> processingTasks = new List<Task>();

                foreach (int num in numbers)
                {
                    processingTasks.Add(ProcessNumberAsync(num));
                }

                await Task.WhenAll(processingTasks);

                return Ok("Processamento conclu�do com sucesso!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro interno do servidor: {ex.Message}");
            }
        }

        private async Task ProcessNumberAsync(int num)
        {
            try
            {
                string fileName = $"tabuada_de_{num}.txt";
                using (StreamWriter writer = new StreamWriter(fileName))
                {
                    for (int i = 1; i <= 10; i++)
                    {
                        int result = num * i;
                        await writer.WriteLineAsync($"{num} x {i} = {result}");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao processar o n�mero {num}: {ex.Message}");
            }
        }
    }
}
